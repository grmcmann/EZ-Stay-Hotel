﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.FIRSTNAME = New System.Windows.Forms.TextBox()
        Me.LASTNAME = New System.Windows.Forms.TextBox()
        Me.STATE = New System.Windows.Forms.TextBox()
        Me.ADDRESS = New System.Windows.Forms.TextBox()
        Me.CITY = New System.Windows.Forms.TextBox()
        Me.ZIP = New System.Windows.Forms.TextBox()
        Me.CCNUMBER = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CCSECURITY = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TELEPHONE = New System.Windows.Forms.TextBox()
        Me.USERNAME = New System.Windows.Forms.TextBox()
        Me.PASSWORD = New System.Windows.Forms.TextBox()
        Me.gdihs = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.GreenYellow
        Me.Button2.Location = New System.Drawing.Point(511, 105)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 34)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.GreenYellow
        Me.Button1.Location = New System.Drawing.Point(423, 105)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 34)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Submit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "First Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(191, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Last Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(480, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Zip:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Address:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(256, 50)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 17)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "City:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(379, 50)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 17)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "State:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(23, 85)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 17)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Card Number:"
        '
        'FIRSTNAME
        '
        Me.FIRSTNAME.Location = New System.Drawing.Point(101, 12)
        Me.FIRSTNAME.Name = "FIRSTNAME"
        Me.FIRSTNAME.Size = New System.Drawing.Size(84, 22)
        Me.FIRSTNAME.TabIndex = 1
        Me.FIRSTNAME.Tag = "Name goes here"
        '
        'LASTNAME
        '
        Me.LASTNAME.Location = New System.Drawing.Point(269, 12)
        Me.LASTNAME.Name = "LASTNAME"
        Me.LASTNAME.Size = New System.Drawing.Size(100, 22)
        Me.LASTNAME.TabIndex = 2
        '
        'STATE
        '
        Me.STATE.Location = New System.Drawing.Point(423, 47)
        Me.STATE.Name = "STATE"
        Me.STATE.Size = New System.Drawing.Size(49, 22)
        Me.STATE.TabIndex = 6
        '
        'ADDRESS
        '
        Me.ADDRESS.Location = New System.Drawing.Point(86, 47)
        Me.ADDRESS.Name = "ADDRESS"
        Me.ADDRESS.Size = New System.Drawing.Size(164, 22)
        Me.ADDRESS.TabIndex = 4
        '
        'CITY
        '
        Me.CITY.Location = New System.Drawing.Point(289, 47)
        Me.CITY.Name = "CITY"
        Me.CITY.Size = New System.Drawing.Size(84, 22)
        Me.CITY.TabIndex = 5
        Me.CITY.Tag = "Name goes here"
        '
        'ZIP
        '
        Me.ZIP.Location = New System.Drawing.Point(511, 47)
        Me.ZIP.Name = "ZIP"
        Me.ZIP.Size = New System.Drawing.Size(75, 22)
        Me.ZIP.TabIndex = 7
        Me.ZIP.Tag = "Name goes here"
        '
        'CCNUMBER
        '
        Me.CCNUMBER.Location = New System.Drawing.Point(120, 82)
        Me.CCNUMBER.Name = "CCNUMBER"
        Me.CCNUMBER.Size = New System.Drawing.Size(127, 22)
        Me.CCNUMBER.TabIndex = 8
        Me.CCNUMBER.Tag = "Name goes here"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(256, 85)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 17)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Security Code:"
        '
        'CCSECURITY
        '
        Me.CCSECURITY.Location = New System.Drawing.Point(357, 82)
        Me.CCSECURITY.Name = "CCSECURITY"
        Me.CCSECURITY.Size = New System.Drawing.Size(55, 22)
        Me.CCSECURITY.TabIndex = 9
        Me.CCSECURITY.Tag = "Name goes here"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(375, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 17)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Telephone:"
        '
        'TELEPHONE
        '
        Me.TELEPHONE.Location = New System.Drawing.Point(455, 12)
        Me.TELEPHONE.Name = "TELEPHONE"
        Me.TELEPHONE.Size = New System.Drawing.Size(131, 22)
        Me.TELEPHONE.TabIndex = 3
        '
        'USERNAME
        '
        Me.USERNAME.Location = New System.Drawing.Point(101, 117)
        Me.USERNAME.Name = "USERNAME"
        Me.USERNAME.Size = New System.Drawing.Size(117, 22)
        Me.USERNAME.TabIndex = 10
        '
        'PASSWORD
        '
        Me.PASSWORD.Location = New System.Drawing.Point(296, 117)
        Me.PASSWORD.Name = "PASSWORD"
        Me.PASSWORD.Size = New System.Drawing.Size(116, 22)
        Me.PASSWORD.TabIndex = 11
        '
        'gdihs
        '
        Me.gdihs.AutoSize = True
        Me.gdihs.Location = New System.Drawing.Point(23, 120)
        Me.gdihs.Name = "gdihs"
        Me.gdihs.Size = New System.Drawing.Size(77, 17)
        Me.gdihs.TabIndex = 23
        Me.gdihs.Text = "Username:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(224, 120)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 17)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "Password:"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(598, 151)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.gdihs)
        Me.Controls.Add(Me.PASSWORD)
        Me.Controls.Add(Me.USERNAME)
        Me.Controls.Add(Me.TELEPHONE)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.CCSECURITY)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CCNUMBER)
        Me.Controls.Add(Me.ZIP)
        Me.Controls.Add(Me.CITY)
        Me.Controls.Add(Me.ADDRESS)
        Me.Controls.Add(Me.STATE)
        Me.Controls.Add(Me.LASTNAME)
        Me.Controls.Add(Me.FIRSTNAME)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Registration"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents FIRSTNAME As TextBox
    Friend WithEvents LASTNAME As TextBox
    Friend WithEvents STATE As TextBox
    Friend WithEvents ADDRESS As TextBox
    Friend WithEvents CITY As TextBox
    Friend WithEvents ZIP As TextBox
    Friend WithEvents CCNUMBER As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CCSECURITY As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TELEPHONE As TextBox
    Friend WithEvents USERNAME As TextBox
    Friend WithEvents PASSWORD As TextBox
    Friend WithEvents gdihs As Label
    Friend WithEvents Label10 As Label
End Class
