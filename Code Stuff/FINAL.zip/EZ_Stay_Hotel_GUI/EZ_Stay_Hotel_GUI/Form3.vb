﻿Imports System.Data.OleDb

Public Class Form3

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'User must fill all fields
        If FIRSTNAME.Text.Equals("") Or
        LASTNAME.Text.Equals("") Or
        TELEPHONE.Text.Equals("") Or
        ADDRESS.Text.Equals("") Or
        CITY.Text.Equals("") Or
        STATE.Text.Equals("") Or
        ZIP.Text.Equals("") Or
        CCNUMBER.Text.Equals("") Or
        CCSECURITY.Text.Equals("") Or
        USERNAME.Text.Equals("") Or
        PASSWORD.Text.Equals("") Then
            Form9.Show()
            Return
        End If
        'Establish connection to database
        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()

        sql = "SELECT * FROM Credentials"

        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        cmd.CommandType = CommandType.Text
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        Dim u As New ArrayList

        'Adds username to list of usernames upon every registration
        If dr.HasRows Then
            While dr.Read() = True
                Dim user As String = dr.Item(0).ToString()
                u.Add(user)
            End While
        End If

        'Prevents duplicate usernames
        If u.Contains("[" & USERNAME.Text & "]") Then
            Form10.Show()
            Return
        Else
            sql = "INSERT INTO Credentials ([USERNAME],
                    [PASSWORD],
                    [FIRSTNAME],
                    [LASTNAME], 
                    [TELEPHONE], 
                    [ADDRESS], 
                    [CITY], 
                    [STATE], 
                    [ZIP], 
                    [CCNUMBER], 
                    [CCSECURITY]) 
                    VALUES ('[" & Trim(USERNAME.Text) & "]',
                    '[" & Trim(PASSWORD.Text) & "]',
                    '[" & Me.FIRSTNAME.Text & "]',
                    '[" & Trim(LASTNAME.Text) & "]',
                    '[" & Trim(TELEPHONE.Text) & "]',
                    '[" & Trim(ADDRESS.Text) & "]',
                    '[" & Trim(CITY.Text) & "]',
                    '[" & Trim(STATE.Text) & "]',
                    '[" & Trim(ZIP.Text) & "]',
                    '[" & Trim(CCNUMBER.Text) & "]',
                    '[" & Trim(CCSECURITY.Text) & "]')"

            cmd = New OleDb.OleDbCommand(sql, con)
            cmd.ExecuteNonQuery()
            con.Close()
            Form4.Show()

            FIRSTNAME.Text = ""
            LASTNAME.Text = ""
            TELEPHONE.Text = ""
            ADDRESS.Text = ""
            CITY.Text = ""
            STATE.Text = ""
            ZIP.Text = ""
            CCNUMBER.Text = ""
            CCSECURITY.Text = ""
            USERNAME.Text = ""
            PASSWORD.Text = ""

        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()
    End Sub
End Class