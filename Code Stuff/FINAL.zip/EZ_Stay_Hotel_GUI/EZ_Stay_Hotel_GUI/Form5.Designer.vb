﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form5))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ROOM002 = New System.Windows.Forms.RadioButton()
        Me.ROOM010 = New System.Windows.Forms.RadioButton()
        Me.ROOM009 = New System.Windows.Forms.RadioButton()
        Me.ROOM008 = New System.Windows.Forms.RadioButton()
        Me.ROOM007 = New System.Windows.Forms.RadioButton()
        Me.ROOM006 = New System.Windows.Forms.RadioButton()
        Me.ROOM005 = New System.Windows.Forms.RadioButton()
        Me.ROOM004 = New System.Windows.Forms.RadioButton()
        Me.ROOM003 = New System.Windows.Forms.RadioButton()
        Me.ROOM001 = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.GreenYellow
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(132, 253)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 34)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.GreenYellow
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(132, 213)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 34)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Submit"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ROOM002
        '
        Me.ROOM002.AutoSize = True
        Me.ROOM002.Location = New System.Drawing.Point(12, 39)
        Me.ROOM002.Name = "ROOM002"
        Me.ROOM002.Size = New System.Drawing.Size(94, 21)
        Me.ROOM002.TabIndex = 20
        Me.ROOM002.TabStop = True
        Me.ROOM002.Text = "Room 002"
        Me.ROOM002.UseVisualStyleBackColor = True
        '
        'ROOM010
        '
        Me.ROOM010.AutoSize = True
        Me.ROOM010.Location = New System.Drawing.Point(12, 255)
        Me.ROOM010.Name = "ROOM010"
        Me.ROOM010.Size = New System.Drawing.Size(94, 21)
        Me.ROOM010.TabIndex = 12
        Me.ROOM010.TabStop = True
        Me.ROOM010.Text = "Room 010"
        Me.ROOM010.UseVisualStyleBackColor = True
        '
        'ROOM009
        '
        Me.ROOM009.AutoSize = True
        Me.ROOM009.Location = New System.Drawing.Point(12, 228)
        Me.ROOM009.Name = "ROOM009"
        Me.ROOM009.Size = New System.Drawing.Size(94, 21)
        Me.ROOM009.TabIndex = 13
        Me.ROOM009.TabStop = True
        Me.ROOM009.Text = "Room 009"
        Me.ROOM009.UseVisualStyleBackColor = True
        '
        'ROOM008
        '
        Me.ROOM008.AutoSize = True
        Me.ROOM008.Location = New System.Drawing.Point(12, 201)
        Me.ROOM008.Name = "ROOM008"
        Me.ROOM008.Size = New System.Drawing.Size(94, 21)
        Me.ROOM008.TabIndex = 14
        Me.ROOM008.TabStop = True
        Me.ROOM008.Text = "Room 008"
        Me.ROOM008.UseVisualStyleBackColor = True
        '
        'ROOM007
        '
        Me.ROOM007.AutoSize = True
        Me.ROOM007.Location = New System.Drawing.Point(12, 174)
        Me.ROOM007.Name = "ROOM007"
        Me.ROOM007.Size = New System.Drawing.Size(94, 21)
        Me.ROOM007.TabIndex = 15
        Me.ROOM007.TabStop = True
        Me.ROOM007.Text = "Room 007"
        Me.ROOM007.UseVisualStyleBackColor = True
        '
        'ROOM006
        '
        Me.ROOM006.AutoSize = True
        Me.ROOM006.Location = New System.Drawing.Point(12, 147)
        Me.ROOM006.Name = "ROOM006"
        Me.ROOM006.Size = New System.Drawing.Size(94, 21)
        Me.ROOM006.TabIndex = 16
        Me.ROOM006.TabStop = True
        Me.ROOM006.Text = "Room 006"
        Me.ROOM006.UseVisualStyleBackColor = True
        '
        'ROOM005
        '
        Me.ROOM005.AutoSize = True
        Me.ROOM005.Location = New System.Drawing.Point(12, 120)
        Me.ROOM005.Name = "ROOM005"
        Me.ROOM005.Size = New System.Drawing.Size(94, 21)
        Me.ROOM005.TabIndex = 17
        Me.ROOM005.TabStop = True
        Me.ROOM005.Text = "Room 005"
        Me.ROOM005.UseVisualStyleBackColor = True
        '
        'ROOM004
        '
        Me.ROOM004.AutoSize = True
        Me.ROOM004.Location = New System.Drawing.Point(12, 93)
        Me.ROOM004.Name = "ROOM004"
        Me.ROOM004.Size = New System.Drawing.Size(94, 21)
        Me.ROOM004.TabIndex = 18
        Me.ROOM004.TabStop = True
        Me.ROOM004.Text = "Room 004"
        Me.ROOM004.UseVisualStyleBackColor = True
        '
        'ROOM003
        '
        Me.ROOM003.AutoSize = True
        Me.ROOM003.Location = New System.Drawing.Point(12, 66)
        Me.ROOM003.Name = "ROOM003"
        Me.ROOM003.Size = New System.Drawing.Size(94, 21)
        Me.ROOM003.TabIndex = 19
        Me.ROOM003.TabStop = True
        Me.ROOM003.Text = "Room 003"
        Me.ROOM003.UseVisualStyleBackColor = True
        '
        'ROOM001
        '
        Me.ROOM001.AutoSize = True
        Me.ROOM001.Location = New System.Drawing.Point(12, 12)
        Me.ROOM001.Name = "ROOM001"
        Me.ROOM001.Size = New System.Drawing.Size(94, 21)
        Me.ROOM001.TabIndex = 3
        Me.ROOM001.TabStop = True
        Me.ROOM001.Text = "Room 001"
        Me.ROOM001.UseVisualStyleBackColor = True
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(219, 299)
        Me.Controls.Add(Me.ROOM002)
        Me.Controls.Add(Me.ROOM003)
        Me.Controls.Add(Me.ROOM004)
        Me.Controls.Add(Me.ROOM005)
        Me.Controls.Add(Me.ROOM006)
        Me.Controls.Add(Me.ROOM007)
        Me.Controls.Add(Me.ROOM008)
        Me.Controls.Add(Me.ROOM009)
        Me.Controls.Add(Me.ROOM010)
        Me.Controls.Add(Me.ROOM001)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form5"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Check-In"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents ROOM002 As RadioButton
    Friend WithEvents ROOM010 As RadioButton
    Friend WithEvents ROOM009 As RadioButton
    Friend WithEvents ROOM008 As RadioButton
    Friend WithEvents ROOM007 As RadioButton
    Friend WithEvents ROOM006 As RadioButton
    Friend WithEvents ROOM005 As RadioButton
    Friend WithEvents ROOM004 As RadioButton
    Friend WithEvents ROOM003 As RadioButton
    Friend WithEvents ROOM001 As RadioButton
End Class
