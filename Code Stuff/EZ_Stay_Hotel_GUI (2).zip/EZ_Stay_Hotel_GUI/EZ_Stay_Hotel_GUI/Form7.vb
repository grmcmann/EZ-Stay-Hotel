﻿Imports System.Data.OleDb
Public Class Form7
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FIRSTNAME.Text.Equals("") Or
        LASTNAME.Text.Equals("") Or
        TELEPHONE.Text.Equals("") Or
        ADDRESS.Text.Equals("") Or
        CITY.Text.Equals("") Or
        STATE.Text.Equals("") Or
        ZIP.Text.Equals("") Or
        CCNUMBER.Text.Equals("") Or
        CCSECURITY.Text.Equals("") Then
            Form9.Show()
            Return
        End If

        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()

        sql = "SELECT USERNAME FROM Credentials WHERE USERNAME = '[" & Form1.getUser() & "']"

        Dim cmd As OleDbCommand = New OleDb.OleDbCommand(sql, con)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        dr.Close()

        sql = "INSERT INTO Credentials (
                    [FIRSTNAME],
                    [LASTNAME], 
                    [TELEPHONE], 
                    [ADDRESS], 
                    [CITY], 
                    [STATE], 
                    [ZIP], 
                    [CCNUMBER], 
                    [CCSECURITY]) 
                    VALUES ('[" & Me.FIRSTNAME.Text & "]',
                    '[" & Trim(LASTNAME.Text) & "]',
                    '[" & Trim(TELEPHONE.Text) & "]',
                    '[" & Trim(ADDRESS.Text) & "]',
                    '[" & Trim(CITY.Text) & "]',
                    '[" & Trim(STATE.Text) & "]',
                    '[" & Trim(ZIP.Text) & "]',
                    '[" & Trim(CCNUMBER.Text) & "]',
                    '[" & Trim(CCSECURITY.Text) & "]')"

        cmd = New OleDb.OleDbCommand(sql, con)
        cmd.ExecuteNonQuery()

            con.Close()
            Form4.Show()

            FIRSTNAME.Text = ""
            LASTNAME.Text = ""
            TELEPHONE.Text = ""
            ADDRESS.Text = ""
            CITY.Text = ""
            STATE.Text = ""
            ZIP.Text = ""
            CCNUMBER.Text = ""
        CCSECURITY.Text = ""
        Form8.Show()
    End Sub
End Class