﻿Imports System.Data.OleDb

Public Class Form2
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form5.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'Ran out of time so this only makes a room not in use if it has been made in use during the same runtime
        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\RoomDB.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()
        sql = "UPDATE Rooms SET INUSE = 0 WHERE ROOM = " & Form5.getRoom()

        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        cmd.CommandType = CommandType.Text
        Dim dr As OleDbDataReader = cmd.ExecuteReader()

        cmd = New OleDb.OleDbCommand(sql, con)
        cmd.ExecuteNonQuery()
        con.Close()
        Form6.Show()
    End Sub
End Class