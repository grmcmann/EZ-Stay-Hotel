﻿Imports System.Data.OleDb
Public Class Form1
    Dim user As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Console.Write(Application.StartupPath)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If USERNAME.Text.Equals("") Or
        PASSWORD.Text.Equals("") Then
            Form9.Show()
            Return
        End If


        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()

        sql = “SELECT USERNAME AND PASSWORD FROM Credentials“

        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        Dim userAl As ArrayList = New ArrayList()
        Dim passAl As ArrayList = New ArrayList()

        While dr.Read() = True
            Dim user As String = dr.GetString(Convert.ToInt32(0))
            Dim pass As String = dr.GetString(Convert.ToInt32(0))
            userAl.Add(user)
            passAl.Add(pass)
        End While

        For index As Integer = 0 To userAl.Count
            If USERNAME.Text.Equals(userAl(index)) And PASSWORD.Text.Equals(passAl(index)) Then
                Hide()
                Form2.Show()
            Else
                Form11.Show()
                Return
            End If
        Next

        user = USERNAME.Text
        dr.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Public Function getUser()
        Return user
    End Function


End Class
