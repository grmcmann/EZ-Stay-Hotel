﻿Imports System.Data.OleDb

Public Class Form5
    Dim room As New Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form2.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\RoomDB.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()

        If ROOM001.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 1"
            room = 1
        ElseIf ROOM002.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 2"
            room = 2
        ElseIf ROOM003.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 3"
            room = 3
        ElseIf ROOM004.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 4"
            room = 4
        ElseIf ROOM005.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 5"
            room = 5
        ElseIf ROOM006.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 6"
            room = 6
        ElseIf ROOM007.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 7"
            room = 7
        ElseIf ROOM008.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 8"
            room = 8
        ElseIf ROOM009.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 9"
            room = 9
        ElseIf ROOM010.Checked Then
            sql = "SELECT * FROM Rooms WHERE ROOM = 10"
            room = 10
        Else
            Form12.Show()
            Return
        End If

        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        cmd.CommandType = CommandType.Text
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        Dim inUse As New Boolean

        If dr.HasRows Then
            If dr.Read() Then
                inUse = dr.GetBoolean(0)
            End If
        End If

        If inUse Then
            Form13.Show()
            Return
        Else
            sql = "UPDATE Rooms SET INUSE = 1 WHERE ROOM = " & room

            cmd = New OleDb.OleDbCommand(sql, con)
            cmd.ExecuteNonQuery()
            con.Close()
            Form14.Show()
        End If
    End Sub
    Public Function getRoom()
        Return room
    End Function
End Class