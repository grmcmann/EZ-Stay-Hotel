﻿Imports System.Data.OleDb
Public Class Form7
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FIRSTNAME.Text.Equals("") Or
        LASTNAME.Text.Equals("") Or
        TELEPHONE.Text.Equals("") Or
        ADDRESS.Text.Equals("") Or
        CITY.Text.Equals("") Or
        STATE.Text.Equals("") Or
        ZIP.Text.Equals("") Or
        CCNUMBER.Text.Equals("") Or
        CCSECURITY.Text.Equals("") Then
            Form9.Show()
            Return
        End If

        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"

        sql = "Update Credentials Set USERNAME ='[" & Form1.getUser() & "]'"

        Using con As New OleDbConnection(conString)

            Using cmd As New OleDbCommand(sql, con)

                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("FIRSTNAME", FIRSTNAME.Text)
                cmd.Parameters.AddWithValue("LASTNAME", LASTNAME.Text)
                cmd.Parameters.AddWithValue("TELEPHONE", TELEPHONE.Text)
                cmd.Parameters.AddWithValue("ADDRESS", ADDRESS.Text)
                cmd.Parameters.AddWithValue("CITY", CITY.Text)
                cmd.Parameters.AddWithValue("STATE", STATE.Text)
                cmd.Parameters.AddWithValue("ZIP", ZIP.Text)
                cmd.Parameters.AddWithValue("CCNUMBER", CCNUMBER.Text)
                cmd.Parameters.AddWithValue("CCSECURITY", CCSECURITY.Text)

                con.Open()

                cmd.ExecuteNonQuery()

            End Using

        End Using
        Form4.Show()

            FIRSTNAME.Text = ""
            LASTNAME.Text = ""
            TELEPHONE.Text = ""
            ADDRESS.Text = ""
            CITY.Text = ""
            STATE.Text = ""
            ZIP.Text = ""
            CCNUMBER.Text = ""
        CCSECURITY.Text = ""
        Form8.Show()
    End Sub
End Class