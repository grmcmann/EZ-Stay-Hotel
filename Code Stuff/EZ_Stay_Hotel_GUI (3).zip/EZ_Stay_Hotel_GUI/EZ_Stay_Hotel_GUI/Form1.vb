﻿Imports System.Data.OleDb
Public Class Form1
    Dim user As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Console.Write(Application.StartupPath)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If USERNAME.Text.Equals("") Or
        PASSWORD.Text.Equals("") Then
            Form9.Show()
            Return
        End If


        Dim sql As String
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()

        sql = “SELECT * FROM Credentials“

        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        cmd.CommandType = CommandType.Text
        Dim dr As OleDbDataReader = cmd.ExecuteReader()
        Dim u As New ArrayList
        Dim p As New ArrayList

        If dr.HasRows Then
            While dr.Read()
                Dim user As String = dr.Item(0).ToString()
                Dim pass As String = dr.Item(0).ToString()
                u.Add(user)
                p.Add(pass)
            End While
        End If

        dr.Close()
        con.Close()

        If u.Contains("[" & USERNAME.Text & "]") And p.Contains("[" & PASSWORD.Text & "]") Then
            If u.IndexOf("[" & USERNAME.Text & "]") = p.IndexOf("[" & PASSWORD.Text & "]") Then
                Form2.Show()
                USERNAME.Text = ""
                PASSWORD.Text = ""
                Me.Hide()
            Else
                Form11.Show()
                USERNAME.Text = ""
                PASSWORD.Text = ""
                Return
            End If
        Else
            Form11.Show()
            USERNAME.Text = ""
            PASSWORD.Text = ""
            Return
        End If

        user = USERNAME.Text

    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Public Function getUser()
        Return user
    End Function


End Class
