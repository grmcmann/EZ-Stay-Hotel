﻿Imports System.Data.OleDb
Public Class Form7
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'User must fill out all fields
        If FIRSTNAME.Text.Equals("") Or
        LASTNAME.Text.Equals("") Or
        TELEPHONE.Text.Equals("") Or
        ADDRESS.Text.Equals("") Or
        CITY.Text.Equals("") Or
        STATE.Text.Equals("") Or
        ZIP.Text.Equals("") Or
        CCNUMBER.Text.Equals("") Or
        CCSECURITY.Text.Equals("") Then
            Form9.Show()
            Return
        End If

        'Establish connection to database
        Dim conString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\Database.mdb"
        Dim con As OleDbConnection = New OleDbConnection(conString)
        con.Open()
        'Update user information
        Dim sql As String = "UPDATE Credentials SET FIRSTNAME = [" & FIRSTNAME.Text & "],
                    LASTNAME = [" & LASTNAME.Text & "], 
                    TELEPHONE = [" & TELEPHONE.Text & "], 
                    ADDRESS = [" & ADDRESS.Text & "], 
                    CITY = [" & CITY.Text & "], 
                    STATE = [" & STATE.Text & "], 
                    ZIP = [" & ZIP.Text & "], 
                    CCNUMBER = [" & CCNUMBER.Text & "], 
                    CCSECURITY = [" & CCSECURITY.Text & "] 
                    Where USERNAME = [" & Form1.getUser() & "]"


        Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
        cmd.ExecuteNonQuery()
        con.Close()
        Form4.Show()

        'Clear fields
        FIRSTNAME.Text = ""
        LASTNAME.Text = ""
        TELEPHONE.Text = ""
        ADDRESS.Text = ""
        CITY.Text = ""
        STATE.Text = ""
        ZIP.Text = ""
        CCNUMBER.Text = ""
        CCSECURITY.Text = ""
        Form8.Show()
    End Sub
End Class