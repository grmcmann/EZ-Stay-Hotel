﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form7))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TELEPHONE = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CCSECURITY = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CCNUMBER = New System.Windows.Forms.TextBox()
        Me.ZIP = New System.Windows.Forms.TextBox()
        Me.CITY = New System.Windows.Forms.TextBox()
        Me.ADDRESS = New System.Windows.Forms.TextBox()
        Me.STATE = New System.Windows.Forms.TextBox()
        Me.LASTNAME = New System.Windows.Forms.TextBox()
        Me.FIRSTNAME = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.GreenYellow
        Me.Button1.Location = New System.Drawing.Point(430, 85)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(143, 34)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "Make Changes"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.GreenYellow
        Me.Button2.Location = New System.Drawing.Point(498, 129)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 34)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TELEPHONE
        '
        Me.TELEPHONE.Location = New System.Drawing.Point(442, 12)
        Me.TELEPHONE.Name = "TELEPHONE"
        Me.TELEPHONE.Size = New System.Drawing.Size(131, 22)
        Me.TELEPHONE.TabIndex = 28
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(362, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(80, 17)
        Me.Label9.TabIndex = 46
        Me.Label9.Text = "Telephone:"
        '
        'CCSECURITY
        '
        Me.CCSECURITY.Location = New System.Drawing.Point(344, 82)
        Me.CCSECURITY.Name = "CCSECURITY"
        Me.CCSECURITY.Size = New System.Drawing.Size(55, 22)
        Me.CCSECURITY.TabIndex = 39
        Me.CCSECURITY.Tag = "Name goes here"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(243, 85)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 17)
        Me.Label8.TabIndex = 45
        Me.Label8.Text = "Security Code:"
        '
        'CCNUMBER
        '
        Me.CCNUMBER.Location = New System.Drawing.Point(107, 82)
        Me.CCNUMBER.Name = "CCNUMBER"
        Me.CCNUMBER.Size = New System.Drawing.Size(127, 22)
        Me.CCNUMBER.TabIndex = 37
        Me.CCNUMBER.Tag = "Name goes here"
        '
        'ZIP
        '
        Me.ZIP.Location = New System.Drawing.Point(498, 47)
        Me.ZIP.Name = "ZIP"
        Me.ZIP.Size = New System.Drawing.Size(75, 22)
        Me.ZIP.TabIndex = 36
        Me.ZIP.Tag = "Name goes here"
        '
        'CITY
        '
        Me.CITY.Location = New System.Drawing.Point(276, 47)
        Me.CITY.Name = "CITY"
        Me.CITY.Size = New System.Drawing.Size(84, 22)
        Me.CITY.TabIndex = 32
        Me.CITY.Tag = "Name goes here"
        '
        'ADDRESS
        '
        Me.ADDRESS.Location = New System.Drawing.Point(73, 47)
        Me.ADDRESS.Name = "ADDRESS"
        Me.ADDRESS.Size = New System.Drawing.Size(164, 22)
        Me.ADDRESS.TabIndex = 29
        '
        'STATE
        '
        Me.STATE.Location = New System.Drawing.Point(410, 47)
        Me.STATE.Name = "STATE"
        Me.STATE.Size = New System.Drawing.Size(49, 22)
        Me.STATE.TabIndex = 33
        '
        'LASTNAME
        '
        Me.LASTNAME.Location = New System.Drawing.Point(256, 12)
        Me.LASTNAME.Name = "LASTNAME"
        Me.LASTNAME.Size = New System.Drawing.Size(100, 22)
        Me.LASTNAME.TabIndex = 26
        '
        'FIRSTNAME
        '
        Me.FIRSTNAME.Location = New System.Drawing.Point(88, 12)
        Me.FIRSTNAME.Name = "FIRSTNAME"
        Me.FIRSTNAME.Size = New System.Drawing.Size(84, 22)
        Me.FIRSTNAME.TabIndex = 25
        Me.FIRSTNAME.Tag = "Name goes here"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 85)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 17)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Card Number:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(366, 50)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 17)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "State:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(243, 50)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 17)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "City:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 17)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(467, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 17)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Zip:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(178, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 17)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Last Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 17)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "First Name:"
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(581, 174)
        Me.Controls.Add(Me.TELEPHONE)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.CCSECURITY)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CCNUMBER)
        Me.Controls.Add(Me.ZIP)
        Me.Controls.Add(Me.CITY)
        Me.Controls.Add(Me.ADDRESS)
        Me.Controls.Add(Me.STATE)
        Me.Controls.Add(Me.LASTNAME)
        Me.Controls.Add(Me.FIRSTNAME)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form7"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Manage Account"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents TELEPHONE As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CCSECURITY As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents CCNUMBER As TextBox
    Friend WithEvents ZIP As TextBox
    Friend WithEvents CITY As TextBox
    Friend WithEvents ADDRESS As TextBox
    Friend WithEvents STATE As TextBox
    Friend WithEvents LASTNAME As TextBox
    Friend WithEvents FIRSTNAME As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
